<<<<<<< HEAD
# TAllele_block

alignment block level implementation of T-Allele
=======
# TAllele_block
>>>>>>> 1dd12585e98e7f2d736565097cda71ead40b4442
